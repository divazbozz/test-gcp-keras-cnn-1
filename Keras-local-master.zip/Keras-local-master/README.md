# Keras-local
# Repository for Keras models that can be run locally on a GPU/CPU, these are not configured for running on cloud or any other engine.